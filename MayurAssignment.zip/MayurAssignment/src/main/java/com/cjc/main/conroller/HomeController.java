package com.cjc.main.conroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.cjc.main.model.Product;
import com.cjc.main.service.HomeService;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;
@RestController
public class HomeController {
	@Autowired
	HomeService hs;
	
	@RequestMapping("/")
	public String prelogin()
	{
		return "login";
	}
	@RequestMapping("register")
	public String registration()
	{
		return "register";
	}
	@RequestMapping("/regd")
	public String registerdata(@ModelAttribute("emp") Product e)
	{
	
		hs.savedata(e);
		return "login";
	
	}
	
	
	@RequestMapping("/edit")
	public String editData(@RequestParam ("eid") int eid,Model m)
	{
		Product emp=hs.editData(eid);
		m.addAttribute("data", emp);
		return "edit";
		
	}
	
	@RequestMapping("/update")
	public String editData(@ModelAttribute ("emp") Product e,Model m)
	{
		hs.savedata(e);
		Iterable<Product> elist=hs.getAlldata();
		m.addAttribute("data", elist);
		return "success";
	}
	@RequestMapping("delete")
	public String deleteData(@ModelAttribute("emp") Product e,Model m)
	{
		hs.deleteData(e);
		Iterable<Product> elist=hs.getAlldata();
		m.addAttribute("data",elist);
		return "success";
	}
	
	

}
