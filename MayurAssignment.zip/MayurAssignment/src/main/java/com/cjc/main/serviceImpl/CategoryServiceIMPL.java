package com.cjc.main.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.main.Repository.CategoryRepository;
import com.cjc.main.Repository.HomeRepository;
import com.cjc.main.model.Category;
import com.cjc.main.model.Product;
import com.cjc.main.service.CategoryService;
import com.cjc.main.service.HomeService;
@Service
public class CategoryServiceIMPL implements CategoryService{

	@Autowired
	CategoryRepository cr;
	
	
	@Override
	public void savedata(Category e) {
		
		cr.save(e);
	}



	@Override
	public Iterable<Category> getAlldata() {
		
		return cr.findAll();
	}


	@Override
	public Category editData(int cid) {
		
		return cr.findAllByEid(cid);
	}


	@Override
	public void deleteData(Category e) {
		
		cr.delete(e);
		
	}


	
	
	



}
