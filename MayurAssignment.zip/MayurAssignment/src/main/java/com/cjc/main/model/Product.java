package com.cjc.main.model;

import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

public class Product {
	
	@Id
	private int pid;
	private String pname;
	@ManyToOne
	private Category pcat;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public Category getPcat() {
		return pcat;
	}
	public void setPcat(Category pcat) {
		this.pcat = pcat;
	}
	

}
