package com.cjc.main.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.main.Repository.HomeRepository;
import com.cjc.main.model.Category;
import com.cjc.main.model.Product;
import com.cjc.main.service.HomeService;
@Service
public class HomeServiceImpl implements HomeService{

	@Autowired
	HomeRepository hr;
	
	
	@Override
	public void savedata(Product e) {
		
		hr.save(e);
	}



	@Override
	public Iterable<Product> getAlldata() {
		
		return hr.findAll();
	}


	@Override
	public Product editData(int eid) {
		
		return hr.findAllByEid(eid);
	}


	@Override
	public void deleteData(Product e) {
		
		hr.delete(e);
		
	}


}
