package com.cjc.main.service;

import com.cjc.main.model.Category;
import com.cjc.main.model.Product;

public interface CategoryService {
	
	public void savedata(Category e);
	
	public Iterable<Category> getAlldata();
	public Category editData(int cid);
	public void deleteData(Category e);
	
	
}
