package com.cjc.main.service;

import com.cjc.main.model.Product;

public interface HomeService {
	
	public void savedata(Product e);
	
	public Iterable<Product> getAlldata();
	public Product editData(int eid);
	public void deleteData(Product e);
	
	
}
